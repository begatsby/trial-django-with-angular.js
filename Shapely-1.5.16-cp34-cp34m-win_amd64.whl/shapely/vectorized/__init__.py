"""Provides multi-point element-wise operations such as ``contains``."""

from ._vectorized import (contains, touches)
